﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmEmpleados
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmEmpleados))
        Me.Label48 = New System.Windows.Forms.Label()
        Me.cbodepartamento = New System.Windows.Forms.ComboBox()
        Me.cbopuesto = New System.Windows.Forms.ComboBox()
        Me.txtdescanso = New System.Windows.Forms.TextBox()
        Me.cbostatus = New System.Windows.Forms.ComboBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.txtcomentarios = New System.Windows.Forms.TextBox()
        Me.txtsalario = New System.Windows.Forms.TextBox()
        Me.cbojornada = New System.Windows.Forms.ComboBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cmdimss = New System.Windows.Forms.Button()
        Me.cmdPension = New System.Windows.Forms.Button()
        Me.cmdDocumentos = New System.Windows.Forms.Button()
        Me.cmdFamiliar = New System.Windows.Forms.Button()
        Me.cmdIncapacidad = New System.Windows.Forms.Button()
        Me.cmdJuridico = New System.Windows.Forms.Button()
        Me.cmdprestamo = New System.Windows.Forms.Button()
        Me.cmdincidencias = New System.Windows.Forms.Button()
        Me.cmdbuscar = New System.Windows.Forms.Button()
        Me.cmdcancelar = New System.Windows.Forms.Button()
        Me.cmdsalir = New System.Windows.Forms.Button()
        Me.cmdguardar = New System.Windows.Forms.Button()
        Me.cbobanco = New System.Windows.Forms.ComboBox()
        Me.txthoras = New System.Windows.Forms.TextBox()
        Me.txthorario = New System.Windows.Forms.TextBox()
        Me.txtcorreo = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.txtduracion = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.dtpantiguedad = New System.Windows.Forms.DateTimePicker()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.gpb1 = New System.Windows.Forms.GroupBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.cboestado = New System.Windows.Forms.ComboBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txtcp = New System.Windows.Forms.TextBox()
        Me.txtciudad = New System.Windows.Forms.TextBox()
        Me.txtdireccion = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.gpb2 = New System.Windows.Forms.GroupBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.cboestadoP = New System.Windows.Forms.ComboBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txtcp2 = New System.Windows.Forms.TextBox()
        Me.txtciudadP = New System.Windows.Forms.TextBox()
        Me.txtdireccionP = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.txtnacionalidad = New System.Windows.Forms.TextBox()
        Me.txtclabe = New System.Windows.Forms.TextBox()
        Me.txtcuenta = New System.Windows.Forms.TextBox()
        Me.txtfactor = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.cbotipofactor = New System.Windows.Forms.ComboBox()
        Me.txtcredito = New System.Windows.Forms.TextBox()
        Me.txtimss = New System.Windows.Forms.TextBox()
        Me.txtrfc = New System.Windows.Forms.TextBox()
        Me.txtcurp = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtedad = New System.Windows.Forms.TextBox()
        Me.dtpfechanac = New System.Windows.Forms.DateTimePicker()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtintegrar = New System.Windows.Forms.TextBox()
        Me.txtsdi = New System.Windows.Forms.TextBox()
        Me.txtsd = New System.Windows.Forms.TextBox()
        Me.dtpsindicato = New System.Windows.Forms.DateTimePicker()
        Me.dtppatrona = New System.Windows.Forms.DateTimePicker()
        Me.cbocategoria = New System.Windows.Forms.ComboBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cboedocivil = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cbosexo = New System.Windows.Forms.ComboBox()
        Me.txtmaterno = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtpaterno = New System.Windows.Forms.TextBox()
        Me.txtnombre = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dtpCaptura = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtcodigo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.cbopertenece = New System.Windows.Forms.ComboBox()
        Me.cbobanco2 = New System.Windows.Forms.ComboBox()
        Me.txtclabe2 = New System.Windows.Forms.TextBox()
        Me.txtcuenta2 = New System.Windows.Forms.TextBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.txtExtra = New System.Windows.Forms.TextBox()
        Me.chkInfonavit = New System.Windows.Forms.CheckBox()
        Me.dtFecPlanta = New System.Windows.Forms.DateTimePicker()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtInicio = New System.Windows.Forms.TextBox()
        Me.txtFin = New System.Windows.Forms.TextBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.txtTelefono = New System.Windows.Forms.TextBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.dtpFinContrato = New System.Windows.Forms.DateTimePicker()
        Me.cmdInfonavit = New System.Windows.Forms.Button()
        Me.cmdPrestam = New System.Windows.Forms.Button()
        Me.cmdFonacot = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.gpb1.SuspendLayout()
        Me.gpb2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(532, 156)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(48, 18)
        Me.Label48.TabIndex = 195
        Me.Label48.Text = "Buque"
        '
        'cbodepartamento
        '
        Me.cbodepartamento.FormattingEnabled = True
        Me.cbodepartamento.Location = New System.Drawing.Point(535, 132)
        Me.cbodepartamento.Name = "cbodepartamento"
        Me.cbodepartamento.Size = New System.Drawing.Size(306, 26)
        Me.cbodepartamento.TabIndex = 194
        '
        'cbopuesto
        '
        Me.cbopuesto.FormattingEnabled = True
        Me.cbopuesto.Location = New System.Drawing.Point(309, 132)
        Me.cbopuesto.Name = "cbopuesto"
        Me.cbopuesto.Size = New System.Drawing.Size(220, 26)
        Me.cbopuesto.TabIndex = 193
        '
        'txtdescanso
        '
        Me.txtdescanso.Location = New System.Drawing.Point(540, 565)
        Me.txtdescanso.Name = "txtdescanso"
        Me.txtdescanso.Size = New System.Drawing.Size(311, 26)
        Me.txtdescanso.TabIndex = 190
        '
        'cbostatus
        '
        Me.cbostatus.FormattingEnabled = True
        Me.cbostatus.Items.AddRange(New Object() {"Activo", "Inactivo"})
        Me.cbostatus.Location = New System.Drawing.Point(64, 7)
        Me.cbostatus.Name = "cbostatus"
        Me.cbostatus.Size = New System.Drawing.Size(169, 26)
        Me.cbostatus.TabIndex = 189
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(10, 10)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(56, 18)
        Me.Label46.TabIndex = 188
        Me.Label46.Text = "Estatus:"
        '
        'txtcomentarios
        '
        Me.txtcomentarios.Location = New System.Drawing.Point(485, 519)
        Me.txtcomentarios.Name = "txtcomentarios"
        Me.txtcomentarios.Size = New System.Drawing.Size(366, 26)
        Me.txtcomentarios.TabIndex = 187
        '
        'txtsalario
        '
        Me.txtsalario.Location = New System.Drawing.Point(389, 519)
        Me.txtsalario.Name = "txtsalario"
        Me.txtsalario.Size = New System.Drawing.Size(86, 26)
        Me.txtsalario.TabIndex = 186
        '
        'cbojornada
        '
        Me.cbojornada.FormattingEnabled = True
        Me.cbojornada.Items.AddRange(New Object() {"SEMANAL", "QUINCENAL", "MENSUAL"})
        Me.cbojornada.Location = New System.Drawing.Point(198, 519)
        Me.cbojornada.Name = "cbojornada"
        Me.cbojornada.Size = New System.Drawing.Size(177, 26)
        Me.cbojornada.TabIndex = 185
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.cmdInfonavit)
        Me.Panel1.Controls.Add(Me.cmdPrestam)
        Me.Panel1.Controls.Add(Me.cmdFonacot)
        Me.Panel1.Controls.Add(Me.cmdimss)
        Me.Panel1.Controls.Add(Me.cmdPension)
        Me.Panel1.Controls.Add(Me.cmdDocumentos)
        Me.Panel1.Controls.Add(Me.cmdFamiliar)
        Me.Panel1.Controls.Add(Me.cmdIncapacidad)
        Me.Panel1.Controls.Add(Me.cmdJuridico)
        Me.Panel1.Controls.Add(Me.cmdprestamo)
        Me.Panel1.Controls.Add(Me.cmdincidencias)
        Me.Panel1.Controls.Add(Me.cmdbuscar)
        Me.Panel1.Controls.Add(Me.cmdcancelar)
        Me.Panel1.Controls.Add(Me.cmdsalir)
        Me.Panel1.Controls.Add(Me.cmdguardar)
        Me.Panel1.Location = New System.Drawing.Point(860, 10)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(205, 689)
        Me.Panel1.TabIndex = 184
        '
        'cmdimss
        '
        Me.cmdimss.Image = CType(resources.GetObject("cmdimss.Image"), System.Drawing.Image)
        Me.cmdimss.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdimss.Location = New System.Drawing.Point(107, 306)
        Me.cmdimss.Name = "cmdimss"
        Me.cmdimss.Size = New System.Drawing.Size(87, 72)
        Me.cmdimss.TabIndex = 47
        Me.cmdimss.Text = "Imss"
        Me.cmdimss.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdimss.UseVisualStyleBackColor = True
        '
        'cmdPension
        '
        Me.cmdPension.Image = CType(resources.GetObject("cmdPension.Image"), System.Drawing.Image)
        Me.cmdPension.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdPension.Location = New System.Drawing.Point(4, 458)
        Me.cmdPension.Name = "cmdPension"
        Me.cmdPension.Size = New System.Drawing.Size(95, 72)
        Me.cmdPension.TabIndex = 44
        Me.cmdPension.Text = "Pensión Ali."
        Me.cmdPension.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdPension.UseVisualStyleBackColor = True
        '
        'cmdDocumentos
        '
        Me.cmdDocumentos.Image = CType(resources.GetObject("cmdDocumentos.Image"), System.Drawing.Image)
        Me.cmdDocumentos.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdDocumentos.Location = New System.Drawing.Point(103, 384)
        Me.cmdDocumentos.Name = "cmdDocumentos"
        Me.cmdDocumentos.Size = New System.Drawing.Size(95, 72)
        Me.cmdDocumentos.TabIndex = 46
        Me.cmdDocumentos.Text = "Documentos"
        Me.cmdDocumentos.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdDocumentos.UseVisualStyleBackColor = True
        '
        'cmdFamiliar
        '
        Me.cmdFamiliar.Image = CType(resources.GetObject("cmdFamiliar.Image"), System.Drawing.Image)
        Me.cmdFamiliar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdFamiliar.Location = New System.Drawing.Point(2, 384)
        Me.cmdFamiliar.Name = "cmdFamiliar"
        Me.cmdFamiliar.Size = New System.Drawing.Size(95, 72)
        Me.cmdFamiliar.TabIndex = 45
        Me.cmdFamiliar.Text = "Familiares"
        Me.cmdFamiliar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdFamiliar.UseVisualStyleBackColor = True
        '
        'cmdIncapacidad
        '
        Me.cmdIncapacidad.Image = CType(resources.GetObject("cmdIncapacidad.Image"), System.Drawing.Image)
        Me.cmdIncapacidad.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdIncapacidad.Location = New System.Drawing.Point(3, 306)
        Me.cmdIncapacidad.Name = "cmdIncapacidad"
        Me.cmdIncapacidad.Size = New System.Drawing.Size(95, 72)
        Me.cmdIncapacidad.TabIndex = 44
        Me.cmdIncapacidad.Text = "Incapacidad"
        Me.cmdIncapacidad.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdIncapacidad.UseVisualStyleBackColor = True
        '
        'cmdJuridico
        '
        Me.cmdJuridico.Image = CType(resources.GetObject("cmdJuridico.Image"), System.Drawing.Image)
        Me.cmdJuridico.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdJuridico.Location = New System.Drawing.Point(4, 533)
        Me.cmdJuridico.Name = "cmdJuridico"
        Me.cmdJuridico.Size = New System.Drawing.Size(95, 72)
        Me.cmdJuridico.TabIndex = 43
        Me.cmdJuridico.Text = "Juridico"
        Me.cmdJuridico.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdJuridico.UseVisualStyleBackColor = True
        '
        'cmdprestamo
        '
        Me.cmdprestamo.Image = CType(resources.GetObject("cmdprestamo.Image"), System.Drawing.Image)
        Me.cmdprestamo.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdprestamo.Location = New System.Drawing.Point(3, 309)
        Me.cmdprestamo.Name = "cmdprestamo"
        Me.cmdprestamo.Size = New System.Drawing.Size(95, 72)
        Me.cmdprestamo.TabIndex = 42
        Me.cmdprestamo.Text = "Prestamo"
        Me.cmdprestamo.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdprestamo.UseVisualStyleBackColor = True
        '
        'cmdincidencias
        '
        Me.cmdincidencias.Image = CType(resources.GetObject("cmdincidencias.Image"), System.Drawing.Image)
        Me.cmdincidencias.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdincidencias.Location = New System.Drawing.Point(3, 231)
        Me.cmdincidencias.Name = "cmdincidencias"
        Me.cmdincidencias.Size = New System.Drawing.Size(94, 72)
        Me.cmdincidencias.TabIndex = 41
        Me.cmdincidencias.Text = "Incidencias"
        Me.cmdincidencias.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdincidencias.UseVisualStyleBackColor = True
        '
        'cmdbuscar
        '
        Me.cmdbuscar.Image = CType(resources.GetObject("cmdbuscar.Image"), System.Drawing.Image)
        Me.cmdbuscar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdbuscar.Location = New System.Drawing.Point(3, 155)
        Me.cmdbuscar.Name = "cmdbuscar"
        Me.cmdbuscar.Size = New System.Drawing.Size(94, 72)
        Me.cmdbuscar.TabIndex = 40
        Me.cmdbuscar.Text = "Buscar"
        Me.cmdbuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdbuscar.UseVisualStyleBackColor = True
        '
        'cmdcancelar
        '
        Me.cmdcancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdcancelar.Image = CType(resources.GetObject("cmdcancelar.Image"), System.Drawing.Image)
        Me.cmdcancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdcancelar.Location = New System.Drawing.Point(4, 82)
        Me.cmdcancelar.Name = "cmdcancelar"
        Me.cmdcancelar.Size = New System.Drawing.Size(91, 72)
        Me.cmdcancelar.TabIndex = 38
        Me.cmdcancelar.Text = "Cancelar"
        Me.cmdcancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdcancelar.UseVisualStyleBackColor = True
        '
        'cmdsalir
        '
        Me.cmdsalir.Image = CType(resources.GetObject("cmdsalir.Image"), System.Drawing.Image)
        Me.cmdsalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdsalir.Location = New System.Drawing.Point(4, 609)
        Me.cmdsalir.Name = "cmdsalir"
        Me.cmdsalir.Size = New System.Drawing.Size(94, 72)
        Me.cmdsalir.TabIndex = 37
        Me.cmdsalir.Text = "Salir"
        Me.cmdsalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdsalir.UseVisualStyleBackColor = True
        '
        'cmdguardar
        '
        Me.cmdguardar.Image = CType(resources.GetObject("cmdguardar.Image"), System.Drawing.Image)
        Me.cmdguardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdguardar.Location = New System.Drawing.Point(3, 4)
        Me.cmdguardar.Name = "cmdguardar"
        Me.cmdguardar.Size = New System.Drawing.Size(91, 72)
        Me.cmdguardar.TabIndex = 34
        Me.cmdguardar.Text = "Guardar"
        Me.cmdguardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdguardar.UseVisualStyleBackColor = True
        '
        'cbobanco
        '
        Me.cbobanco.FormattingEnabled = True
        Me.cbobanco.Location = New System.Drawing.Point(339, 309)
        Me.cbobanco.Name = "cbobanco"
        Me.cbobanco.Size = New System.Drawing.Size(177, 26)
        Me.cbobanco.TabIndex = 181
        '
        'txthoras
        '
        Me.txthoras.Location = New System.Drawing.Point(435, 565)
        Me.txthoras.Name = "txthoras"
        Me.txthoras.Size = New System.Drawing.Size(94, 26)
        Me.txthoras.TabIndex = 180
        '
        'txthorario
        '
        Me.txthorario.Location = New System.Drawing.Point(255, 565)
        Me.txthorario.Name = "txthorario"
        Me.txthorario.Size = New System.Drawing.Size(174, 26)
        Me.txthorario.TabIndex = 179
        '
        'txtcorreo
        '
        Me.txtcorreo.Location = New System.Drawing.Point(8, 565)
        Me.txtcorreo.Name = "txtcorreo"
        Me.txtcorreo.Size = New System.Drawing.Size(241, 26)
        Me.txtcorreo.TabIndex = 178
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(537, 588)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(88, 18)
        Me.Label45.TabIndex = 177
        Me.Label45.Text = "Dia descanso"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(433, 588)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(98, 18)
        Me.Label44.TabIndex = 176
        Me.Label44.Text = "Num. de horas"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(256, 588)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(122, 18)
        Me.Label43.TabIndex = 175
        Me.Label43.Text = "Horario de labores"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(5, 588)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(123, 18)
        Me.Label42.TabIndex = 174
        Me.Label42.Text = "Correo electrónico"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(482, 542)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(87, 18)
        Me.Label41.TabIndex = 173
        Me.Label41.Text = "Comentarios"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(389, 542)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(77, 18)
        Me.Label40.TabIndex = 172
        Me.Label40.Text = "Salario real"
        '
        'txtduracion
        '
        Me.txtduracion.Location = New System.Drawing.Point(8, 519)
        Me.txtduracion.Name = "txtduracion"
        Me.txtduracion.Size = New System.Drawing.Size(179, 26)
        Me.txtduracion.TabIndex = 171
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(195, 542)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(85, 18)
        Me.Label39.TabIndex = 170
        Me.Label39.Text = "Tipo jornada"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(5, 542)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(141, 18)
        Me.Label38.TabIndex = 169
        Me.Label38.Text = "Duracion del contrato"
        '
        'dtpantiguedad
        '
        Me.dtpantiguedad.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpantiguedad.Location = New System.Drawing.Point(449, 220)
        Me.dtpantiguedad.Name = "dtpantiguedad"
        Me.dtpantiguedad.Size = New System.Drawing.Size(91, 26)
        Me.dtpantiguedad.TabIndex = 168
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(446, 244)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(135, 18)
        Me.Label37.TabIndex = 167
        Me.Label37.Text = "Fecha de antiguedad"
        '
        'gpb1
        '
        Me.gpb1.Controls.Add(Me.Label35)
        Me.gpb1.Controls.Add(Me.cboestado)
        Me.gpb1.Controls.Add(Me.Label34)
        Me.gpb1.Controls.Add(Me.txtcp)
        Me.gpb1.Controls.Add(Me.txtciudad)
        Me.gpb1.Controls.Add(Me.txtdireccion)
        Me.gpb1.Controls.Add(Me.Label33)
        Me.gpb1.Controls.Add(Me.Label29)
        Me.gpb1.Location = New System.Drawing.Point(8, 362)
        Me.gpb1.Name = "gpb1"
        Me.gpb1.Size = New System.Drawing.Size(843, 76)
        Me.gpb1.TabIndex = 166
        Me.gpb1.TabStop = False
        Me.gpb1.Text = "Direccion del trabajador"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(789, 48)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(30, 18)
        Me.Label35.TabIndex = 77
        Me.Label35.Text = "C.P."
        '
        'cboestado
        '
        Me.cboestado.FormattingEnabled = True
        Me.cboestado.Location = New System.Drawing.Point(564, 25)
        Me.cboestado.Name = "cboestado"
        Me.cboestado.Size = New System.Drawing.Size(216, 26)
        Me.cboestado.TabIndex = 76
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(561, 48)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(49, 18)
        Me.Label34.TabIndex = 75
        Me.Label34.Text = "Estado"
        '
        'txtcp
        '
        Me.txtcp.Location = New System.Drawing.Point(790, 25)
        Me.txtcp.MaxLength = 5
        Me.txtcp.Name = "txtcp"
        Me.txtcp.Size = New System.Drawing.Size(51, 26)
        Me.txtcp.TabIndex = 74
        '
        'txtciudad
        '
        Me.txtciudad.Location = New System.Drawing.Point(368, 25)
        Me.txtciudad.Name = "txtciudad"
        Me.txtciudad.Size = New System.Drawing.Size(190, 26)
        Me.txtciudad.TabIndex = 73
        '
        'txtdireccion
        '
        Me.txtdireccion.Location = New System.Drawing.Point(5, 25)
        Me.txtdireccion.Name = "txtdireccion"
        Me.txtdireccion.Size = New System.Drawing.Size(357, 26)
        Me.txtdireccion.TabIndex = 72
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(370, 48)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(51, 18)
        Me.Label33.TabIndex = 71
        Me.Label33.Text = "Ciudad"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(2, 48)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(320, 18)
        Me.Label29.TabIndex = 70
        Me.Label29.Text = "Dirección (Calle, Ext., Int., Delegacion o municipio)"
        '
        'gpb2
        '
        Me.gpb2.Controls.Add(Me.Label30)
        Me.gpb2.Controls.Add(Me.cboestadoP)
        Me.gpb2.Controls.Add(Me.Label31)
        Me.gpb2.Controls.Add(Me.txtcp2)
        Me.gpb2.Controls.Add(Me.txtciudadP)
        Me.gpb2.Controls.Add(Me.txtdireccionP)
        Me.gpb2.Controls.Add(Me.Label32)
        Me.gpb2.Controls.Add(Me.Label36)
        Me.gpb2.Location = New System.Drawing.Point(8, 444)
        Me.gpb2.Name = "gpb2"
        Me.gpb2.Size = New System.Drawing.Size(843, 69)
        Me.gpb2.TabIndex = 165
        Me.gpb2.TabStop = False
        Me.gpb2.Text = "Lugar de prestación de servicios"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(787, 46)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(30, 18)
        Me.Label30.TabIndex = 85
        Me.Label30.Text = "C.P."
        '
        'cboestadoP
        '
        Me.cboestadoP.FormattingEnabled = True
        Me.cboestadoP.Location = New System.Drawing.Point(562, 23)
        Me.cboestadoP.Name = "cboestadoP"
        Me.cboestadoP.Size = New System.Drawing.Size(216, 26)
        Me.cboestadoP.TabIndex = 84
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(559, 46)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(49, 18)
        Me.Label31.TabIndex = 83
        Me.Label31.Text = "Estado"
        '
        'txtcp2
        '
        Me.txtcp2.Location = New System.Drawing.Point(788, 23)
        Me.txtcp2.MaxLength = 5
        Me.txtcp2.Name = "txtcp2"
        Me.txtcp2.Size = New System.Drawing.Size(51, 26)
        Me.txtcp2.TabIndex = 82
        '
        'txtciudadP
        '
        Me.txtciudadP.Location = New System.Drawing.Point(366, 23)
        Me.txtciudadP.Name = "txtciudadP"
        Me.txtciudadP.Size = New System.Drawing.Size(190, 26)
        Me.txtciudadP.TabIndex = 81
        '
        'txtdireccionP
        '
        Me.txtdireccionP.Location = New System.Drawing.Point(3, 23)
        Me.txtdireccionP.Name = "txtdireccionP"
        Me.txtdireccionP.Size = New System.Drawing.Size(357, 26)
        Me.txtdireccionP.TabIndex = 80
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(368, 46)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(51, 18)
        Me.Label32.TabIndex = 79
        Me.Label32.Text = "Ciudad"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(0, 46)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(320, 18)
        Me.Label36.TabIndex = 78
        Me.Label36.Text = "Dirección (Calle, Ext., Int., Delegacion o municipio)"
        '
        'txtnacionalidad
        '
        Me.txtnacionalidad.Location = New System.Drawing.Point(522, 309)
        Me.txtnacionalidad.Name = "txtnacionalidad"
        Me.txtnacionalidad.Size = New System.Drawing.Size(179, 26)
        Me.txtnacionalidad.TabIndex = 164
        '
        'txtclabe
        '
        Me.txtclabe.Location = New System.Drawing.Point(148, 312)
        Me.txtclabe.Name = "txtclabe"
        Me.txtclabe.Size = New System.Drawing.Size(179, 26)
        Me.txtclabe.TabIndex = 163
        '
        'txtcuenta
        '
        Me.txtcuenta.Location = New System.Drawing.Point(9, 312)
        Me.txtcuenta.Name = "txtcuenta"
        Me.txtcuenta.Size = New System.Drawing.Size(127, 26)
        Me.txtcuenta.TabIndex = 162
        '
        'txtfactor
        '
        Me.txtfactor.Location = New System.Drawing.Point(318, 265)
        Me.txtfactor.Name = "txtfactor"
        Me.txtfactor.Size = New System.Drawing.Size(121, 26)
        Me.txtfactor.TabIndex = 160
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(180, 288)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(95, 18)
        Me.Label28.TabIndex = 159
        Me.Label28.Text = "Tipo de Factor"
        '
        'cbotipofactor
        '
        Me.cbotipofactor.FormattingEnabled = True
        Me.cbotipofactor.Items.AddRange(New Object() {"VSM", "PORCENTAJE", "CUOTA FIJA"})
        Me.cbotipofactor.Location = New System.Drawing.Point(183, 265)
        Me.cbotipofactor.Name = "cbotipofactor"
        Me.cbotipofactor.Size = New System.Drawing.Size(126, 26)
        Me.cbotipofactor.TabIndex = 158
        '
        'txtcredito
        '
        Me.txtcredito.Location = New System.Drawing.Point(10, 265)
        Me.txtcredito.Name = "txtcredito"
        Me.txtcredito.Size = New System.Drawing.Size(161, 26)
        Me.txtcredito.TabIndex = 157
        '
        'txtimss
        '
        Me.txtimss.Location = New System.Drawing.Point(306, 220)
        Me.txtimss.Name = "txtimss"
        Me.txtimss.Size = New System.Drawing.Size(121, 26)
        Me.txtimss.TabIndex = 156
        '
        'txtrfc
        '
        Me.txtrfc.Location = New System.Drawing.Point(179, 220)
        Me.txtrfc.Name = "txtrfc"
        Me.txtrfc.Size = New System.Drawing.Size(121, 26)
        Me.txtrfc.TabIndex = 155
        '
        'txtcurp
        '
        Me.txtcurp.Location = New System.Drawing.Point(10, 220)
        Me.txtcurp.Name = "txtcurp"
        Me.txtcurp.Size = New System.Drawing.Size(161, 26)
        Me.txtcurp.TabIndex = 154
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(519, 335)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(89, 18)
        Me.Label27.TabIndex = 153
        Me.Label27.Text = "Nacionalidad"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(333, 335)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(45, 18)
        Me.Label26.TabIndex = 152
        Me.Label26.Text = "Banco"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(145, 335)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(43, 18)
        Me.Label25.TabIndex = 151
        Me.Label25.Text = "Clabe"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(6, 335)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(104, 18)
        Me.Label24.TabIndex = 150
        Me.Label24.Text = "Numero cuenta"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(315, 288)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(133, 18)
        Me.Label23.TabIndex = 149
        Me.Label23.Text = "Factor de descuento"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(7, 288)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(113, 18)
        Me.Label22.TabIndex = 148
        Me.Label22.Text = "Crédito Infonavit"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(306, 244)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(38, 18)
        Me.Label20.TabIndex = 146
        Me.Label20.Text = "IMSS"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(180, 244)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(31, 18)
        Me.Label19.TabIndex = 145
        Me.Label19.Text = "RFC"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(7, 244)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(41, 18)
        Me.Label18.TabIndex = 144
        Me.Label18.Text = "CURP"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(751, 199)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(38, 18)
        Me.Label17.TabIndex = 143
        Me.Label17.Text = "Edad"
        '
        'txtedad
        '
        Me.txtedad.Location = New System.Drawing.Point(754, 177)
        Me.txtedad.Name = "txtedad"
        Me.txtedad.Size = New System.Drawing.Size(86, 26)
        Me.txtedad.TabIndex = 142
        '
        'dtpfechanac
        '
        Me.dtpfechanac.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpfechanac.Location = New System.Drawing.Point(657, 177)
        Me.dtpfechanac.Name = "dtpfechanac"
        Me.dtpfechanac.Size = New System.Drawing.Size(91, 26)
        Me.dtpfechanac.TabIndex = 141
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(657, 199)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(70, 18)
        Me.Label16.TabIndex = 140
        Me.Label16.Text = "Fecha Nac"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(286, 199)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(67, 18)
        Me.Label15.TabIndex = 139
        Me.Label15.Text = "Integrar a"
        '
        'txtintegrar
        '
        Me.txtintegrar.Location = New System.Drawing.Point(286, 177)
        Me.txtintegrar.Name = "txtintegrar"
        Me.txtintegrar.Size = New System.Drawing.Size(153, 26)
        Me.txtintegrar.TabIndex = 138
        '
        'txtsdi
        '
        Me.txtsdi.Location = New System.Drawing.Point(551, 177)
        Me.txtsdi.Name = "txtsdi"
        Me.txtsdi.Size = New System.Drawing.Size(100, 26)
        Me.txtsdi.TabIndex = 137
        '
        'txtsd
        '
        Me.txtsd.Location = New System.Drawing.Point(445, 177)
        Me.txtsd.Name = "txtsd"
        Me.txtsd.Size = New System.Drawing.Size(100, 26)
        Me.txtsd.TabIndex = 136
        '
        'dtpsindicato
        '
        Me.dtpsindicato.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpsindicato.Location = New System.Drawing.Point(177, 177)
        Me.dtpsindicato.Name = "dtpsindicato"
        Me.dtpsindicato.Size = New System.Drawing.Size(91, 26)
        Me.dtpsindicato.TabIndex = 135
        '
        'dtppatrona
        '
        Me.dtppatrona.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtppatrona.Location = New System.Drawing.Point(80, 177)
        Me.dtppatrona.Name = "dtppatrona"
        Me.dtppatrona.Size = New System.Drawing.Size(91, 26)
        Me.dtppatrona.TabIndex = 134
        '
        'cbocategoria
        '
        Me.cbocategoria.FormattingEnabled = True
        Me.cbocategoria.Items.AddRange(New Object() {"A", "B"})
        Me.cbocategoria.Location = New System.Drawing.Point(10, 177)
        Me.cbocategoria.Name = "cbocategoria"
        Me.cbocategoria.Size = New System.Drawing.Size(64, 26)
        Me.cbocategoria.TabIndex = 133
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(548, 199)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(28, 18)
        Me.Label14.TabIndex = 132
        Me.Label14.Text = "SDI"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(442, 199)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(90, 18)
        Me.Label13.TabIndex = 131
        Me.Label13.Text = "Salario Diario"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(176, 199)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(104, 18)
        Me.Label12.TabIndex = 130
        Me.Label12.Text = "Fecha Sindicato"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(80, 199)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(95, 18)
        Me.Label11.TabIndex = 129
        Me.Label11.Text = "Fecha Patrona"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(7, 199)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(67, 18)
        Me.Label10.TabIndex = 128
        Me.Label10.Text = "Categoria"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(306, 156)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(51, 18)
        Me.Label8.TabIndex = 125
        Me.Label8.Text = "Puesto"
        '
        'cboedocivil
        '
        Me.cboedocivil.FormattingEnabled = True
        Me.cboedocivil.Items.AddRange(New Object() {"Soltero", "Casado"})
        Me.cboedocivil.Location = New System.Drawing.Point(158, 132)
        Me.cboedocivil.Name = "cboedocivil"
        Me.cboedocivil.Size = New System.Drawing.Size(142, 26)
        Me.cboedocivil.TabIndex = 124
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(154, 156)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(79, 18)
        Me.Label7.TabIndex = 123
        Me.Label7.Text = "Estado Civil"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(7, 156)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 18)
        Me.Label6.TabIndex = 122
        Me.Label6.Text = "Sexo"
        '
        'cbosexo
        '
        Me.cbosexo.FormattingEnabled = True
        Me.cbosexo.Items.AddRange(New Object() {"Femenino", "Masculino"})
        Me.cbosexo.Location = New System.Drawing.Point(10, 132)
        Me.cbosexo.Name = "cbosexo"
        Me.cbosexo.Size = New System.Drawing.Size(142, 26)
        Me.cbosexo.TabIndex = 121
        '
        'txtmaterno
        '
        Me.txtmaterno.Location = New System.Drawing.Point(252, 86)
        Me.txtmaterno.Name = "txtmaterno"
        Me.txtmaterno.Size = New System.Drawing.Size(223, 26)
        Me.txtmaterno.TabIndex = 120
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(249, 111)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(117, 18)
        Me.Label5.TabIndex = 119
        Me.Label5.Text = "Apellido Materno"
        '
        'txtpaterno
        '
        Me.txtpaterno.Location = New System.Drawing.Point(10, 86)
        Me.txtpaterno.Name = "txtpaterno"
        Me.txtpaterno.Size = New System.Drawing.Size(223, 26)
        Me.txtpaterno.TabIndex = 118
        '
        'txtnombre
        '
        Me.txtnombre.Location = New System.Drawing.Point(492, 86)
        Me.txtnombre.Name = "txtnombre"
        Me.txtnombre.Size = New System.Drawing.Size(240, 26)
        Me.txtnombre.TabIndex = 117
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(139, 61)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(72, 18)
        Me.Label4.TabIndex = 116
        Me.Label4.Text = "Fecha Alta"
        '
        'dtpCaptura
        '
        Me.dtpCaptura.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpCaptura.Location = New System.Drawing.Point(142, 39)
        Me.dtpCaptura.Name = "dtpCaptura"
        Me.dtpCaptura.Size = New System.Drawing.Size(91, 26)
        Me.dtpCaptura.TabIndex = 115
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 111)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(113, 18)
        Me.Label3.TabIndex = 114
        Me.Label3.Text = "Apellido Paterno"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(489, 111)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 18)
        Me.Label2.TabIndex = 113
        Me.Label2.Text = "Nombre(s)"
        '
        'txtcodigo
        '
        Me.txtcodigo.Location = New System.Drawing.Point(10, 39)
        Me.txtcodigo.Name = "txtcodigo"
        Me.txtcodigo.Size = New System.Drawing.Size(100, 26)
        Me.txtcodigo.TabIndex = 112
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 18)
        Me.Label1.TabIndex = 111
        Me.Label1.Text = "Codigo:"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(259, 61)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(111, 18)
        Me.Label49.TabIndex = 197
        Me.Label49.Text = "Tipo empleados:"
        '
        'cbopertenece
        '
        Me.cbopertenece.FormattingEnabled = True
        Me.cbopertenece.Items.AddRange(New Object() {"Interino", "Planta"})
        Me.cbopertenece.Location = New System.Drawing.Point(260, 39)
        Me.cbopertenece.Name = "cbopertenece"
        Me.cbopertenece.Size = New System.Drawing.Size(143, 26)
        Me.cbopertenece.TabIndex = 198
        '
        'cbobanco2
        '
        Me.cbobanco2.FormattingEnabled = True
        Me.cbobanco2.Location = New System.Drawing.Point(342, 658)
        Me.cbobanco2.Name = "cbobanco2"
        Me.cbobanco2.Size = New System.Drawing.Size(177, 26)
        Me.cbobanco2.TabIndex = 204
        '
        'txtclabe2
        '
        Me.txtclabe2.Location = New System.Drawing.Point(151, 658)
        Me.txtclabe2.Name = "txtclabe2"
        Me.txtclabe2.Size = New System.Drawing.Size(179, 26)
        Me.txtclabe2.TabIndex = 203
        '
        'txtcuenta2
        '
        Me.txtcuenta2.Location = New System.Drawing.Point(12, 658)
        Me.txtcuenta2.Name = "txtcuenta2"
        Me.txtcuenta2.Size = New System.Drawing.Size(127, 26)
        Me.txtcuenta2.TabIndex = 202
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(336, 681)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(45, 18)
        Me.Label47.TabIndex = 201
        Me.Label47.Text = "Banco"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(148, 681)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(43, 18)
        Me.Label50.TabIndex = 200
        Me.Label50.Text = "Clabe"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(9, 681)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(104, 18)
        Me.Label51.TabIndex = 199
        Me.Label51.Text = "Numero cuenta"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(442, 633)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(99, 18)
        Me.Label52.TabIndex = 205
        Me.Label52.Text = "Sindicato Extra"
        '
        'txtExtra
        '
        Me.txtExtra.Location = New System.Drawing.Point(443, 609)
        Me.txtExtra.Name = "txtExtra"
        Me.txtExtra.Size = New System.Drawing.Size(98, 26)
        Me.txtExtra.TabIndex = 206
        '
        'chkInfonavit
        '
        Me.chkInfonavit.AutoSize = True
        Me.chkInfonavit.Location = New System.Drawing.Point(454, 269)
        Me.chkInfonavit.Name = "chkInfonavit"
        Me.chkInfonavit.Size = New System.Drawing.Size(124, 22)
        Me.chkInfonavit.TabIndex = 207
        Me.chkInfonavit.Text = "Infonavit Activo"
        Me.chkInfonavit.UseVisualStyleBackColor = True
        '
        'dtFecPlanta
        '
        Me.dtFecPlanta.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtFecPlanta.Location = New System.Drawing.Point(560, 609)
        Me.dtFecPlanta.Name = "dtFecPlanta"
        Me.dtFecPlanta.Size = New System.Drawing.Size(91, 26)
        Me.dtFecPlanta.TabIndex = 208
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(557, 633)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(105, 18)
        Me.Label21.TabIndex = 209
        Me.Label21.Text = "Fecha de Planta"
        '
        'txtInicio
        '
        Me.txtInicio.Location = New System.Drawing.Point(540, 657)
        Me.txtInicio.Name = "txtInicio"
        Me.txtInicio.Size = New System.Drawing.Size(148, 26)
        Me.txtInicio.TabIndex = 210
        '
        'txtFin
        '
        Me.txtFin.Location = New System.Drawing.Point(707, 657)
        Me.txtFin.Name = "txtFin"
        Me.txtFin.Size = New System.Drawing.Size(153, 26)
        Me.txtFin.TabIndex = 211
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(548, 681)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(109, 18)
        Me.Label53.TabIndex = 212
        Me.Label53.Text = "Inicio embarque"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(716, 678)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(125, 18)
        Me.Label54.TabIndex = 213
        Me.Label54.Text = "Termino Embarque"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(609, 243)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(63, 18)
        Me.Label55.TabIndex = 215
        Me.Label55.Text = "Telefono"
        '
        'txtTelefono
        '
        Me.txtTelefono.Location = New System.Drawing.Point(608, 220)
        Me.txtTelefono.Name = "txtTelefono"
        Me.txtTelefono.Size = New System.Drawing.Size(153, 26)
        Me.txtTelefono.TabIndex = 214
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(683, 633)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(170, 18)
        Me.Label56.TabIndex = 217
        Me.Label56.Text = "Fecha de Final de contrato"
        '
        'dtpFinContrato
        '
        Me.dtpFinContrato.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinContrato.Location = New System.Drawing.Point(686, 609)
        Me.dtpFinContrato.Name = "dtpFinContrato"
        Me.dtpFinContrato.Size = New System.Drawing.Size(154, 26)
        Me.dtpFinContrato.TabIndex = 216
        '
        'cmdInfonavit
        '
        Me.cmdInfonavit.Image = CType(resources.GetObject("cmdInfonavit.Image"), System.Drawing.Image)
        Me.cmdInfonavit.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdInfonavit.Location = New System.Drawing.Point(103, 3)
        Me.cmdInfonavit.Name = "cmdInfonavit"
        Me.cmdInfonavit.Size = New System.Drawing.Size(95, 72)
        Me.cmdInfonavit.TabIndex = 54
        Me.cmdInfonavit.Text = "INFONAVIT"
        Me.cmdInfonavit.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdInfonavit.UseVisualStyleBackColor = True
        '
        'cmdPrestam
        '
        Me.cmdPrestam.Image = CType(resources.GetObject("cmdPrestam.Image"), System.Drawing.Image)
        Me.cmdPrestam.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdPrestam.Location = New System.Drawing.Point(101, 81)
        Me.cmdPrestam.Name = "cmdPrestam"
        Me.cmdPrestam.Size = New System.Drawing.Size(95, 72)
        Me.cmdPrestam.TabIndex = 53
        Me.cmdPrestam.Text = "Prestamo"
        Me.cmdPrestam.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdPrestam.UseVisualStyleBackColor = True
        '
        'cmdFonacot
        '
        Me.cmdFonacot.Image = CType(resources.GetObject("cmdFonacot.Image"), System.Drawing.Image)
        Me.cmdFonacot.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdFonacot.Location = New System.Drawing.Point(103, 157)
        Me.cmdFonacot.Name = "cmdFonacot"
        Me.cmdFonacot.Size = New System.Drawing.Size(95, 72)
        Me.cmdFonacot.TabIndex = 52
        Me.cmdFonacot.Text = "Fonacot"
        Me.cmdFonacot.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdFonacot.UseVisualStyleBackColor = True
        '
        'frmEmpleados
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(1077, 705)
        Me.Controls.Add(Me.Label56)
        Me.Controls.Add(Me.dtpFinContrato)
        Me.Controls.Add(Me.Label55)
        Me.Controls.Add(Me.txtTelefono)
        Me.Controls.Add(Me.Label54)
        Me.Controls.Add(Me.Label53)
        Me.Controls.Add(Me.txtFin)
        Me.Controls.Add(Me.txtInicio)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.dtFecPlanta)
        Me.Controls.Add(Me.chkInfonavit)
        Me.Controls.Add(Me.txtExtra)
        Me.Controls.Add(Me.Label52)
        Me.Controls.Add(Me.cbobanco2)
        Me.Controls.Add(Me.txtclabe2)
        Me.Controls.Add(Me.txtcuenta2)
        Me.Controls.Add(Me.Label47)
        Me.Controls.Add(Me.Label50)
        Me.Controls.Add(Me.Label51)
        Me.Controls.Add(Me.cbopertenece)
        Me.Controls.Add(Me.Label49)
        Me.Controls.Add(Me.Label48)
        Me.Controls.Add(Me.cbodepartamento)
        Me.Controls.Add(Me.cbopuesto)
        Me.Controls.Add(Me.txtdescanso)
        Me.Controls.Add(Me.cbostatus)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.txtcomentarios)
        Me.Controls.Add(Me.txtsalario)
        Me.Controls.Add(Me.cbojornada)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.cbobanco)
        Me.Controls.Add(Me.txthoras)
        Me.Controls.Add(Me.txthorario)
        Me.Controls.Add(Me.txtcorreo)
        Me.Controls.Add(Me.Label45)
        Me.Controls.Add(Me.Label44)
        Me.Controls.Add(Me.Label43)
        Me.Controls.Add(Me.Label42)
        Me.Controls.Add(Me.Label41)
        Me.Controls.Add(Me.Label40)
        Me.Controls.Add(Me.txtduracion)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.dtpantiguedad)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.gpb1)
        Me.Controls.Add(Me.gpb2)
        Me.Controls.Add(Me.txtnacionalidad)
        Me.Controls.Add(Me.txtclabe)
        Me.Controls.Add(Me.txtcuenta)
        Me.Controls.Add(Me.txtfactor)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.cbotipofactor)
        Me.Controls.Add(Me.txtcredito)
        Me.Controls.Add(Me.txtimss)
        Me.Controls.Add(Me.txtrfc)
        Me.Controls.Add(Me.txtcurp)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.txtedad)
        Me.Controls.Add(Me.dtpfechanac)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.txtintegrar)
        Me.Controls.Add(Me.txtsdi)
        Me.Controls.Add(Me.txtsd)
        Me.Controls.Add(Me.dtpsindicato)
        Me.Controls.Add(Me.dtppatrona)
        Me.Controls.Add(Me.cbocategoria)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.cboedocivil)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cbosexo)
        Me.Controls.Add(Me.txtmaterno)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtpaterno)
        Me.Controls.Add(Me.txtnombre)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.dtpCaptura)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtcodigo)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmEmpleados"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Alta o modificación de empleados"
        Me.Panel1.ResumeLayout(False)
        Me.gpb1.ResumeLayout(False)
        Me.gpb1.PerformLayout()
        Me.gpb2.ResumeLayout(False)
        Me.gpb2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label48 As Label
    Friend WithEvents cbodepartamento As ComboBox
    Friend WithEvents cbopuesto As ComboBox
    Friend WithEvents txtdescanso As TextBox
    Friend WithEvents cbostatus As ComboBox
    Friend WithEvents Label46 As Label
    Friend WithEvents txtcomentarios As TextBox
    Friend WithEvents txtsalario As TextBox
    Friend WithEvents cbojornada As ComboBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents cmdbuscar As Button
    Friend WithEvents cmdcancelar As Button
    Friend WithEvents cmdsalir As Button
    Friend WithEvents cmdguardar As Button
    Friend WithEvents cbobanco As ComboBox
    Friend WithEvents txthoras As TextBox
    Friend WithEvents txthorario As TextBox
    Friend WithEvents txtcorreo As TextBox
    Friend WithEvents Label45 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents txtduracion As TextBox
    Friend WithEvents Label39 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents dtpantiguedad As DateTimePicker
    Friend WithEvents Label37 As Label
    Friend WithEvents gpb1 As GroupBox
    Friend WithEvents Label35 As Label
    Friend WithEvents cboestado As ComboBox
    Friend WithEvents Label34 As Label
    Friend WithEvents txtcp As TextBox
    Friend WithEvents txtciudad As TextBox
    Friend WithEvents txtdireccion As TextBox
    Friend WithEvents Label33 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents gpb2 As GroupBox
    Friend WithEvents Label30 As Label
    Friend WithEvents cboestadoP As ComboBox
    Friend WithEvents Label31 As Label
    Friend WithEvents txtcp2 As TextBox
    Friend WithEvents txtciudadP As TextBox
    Friend WithEvents txtdireccionP As TextBox
    Friend WithEvents Label32 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents txtnacionalidad As TextBox
    Friend WithEvents txtclabe As TextBox
    Friend WithEvents txtcuenta As TextBox
    Friend WithEvents txtfactor As TextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents cbotipofactor As ComboBox
    Friend WithEvents txtcredito As TextBox
    Friend WithEvents txtimss As TextBox
    Friend WithEvents txtrfc As TextBox
    Friend WithEvents txtcurp As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents txtedad As TextBox
    Friend WithEvents dtpfechanac As DateTimePicker
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents txtintegrar As TextBox
    Friend WithEvents txtsdi As TextBox
    Friend WithEvents txtsd As TextBox
    Friend WithEvents dtpsindicato As DateTimePicker
    Friend WithEvents dtppatrona As DateTimePicker
    Friend WithEvents cbocategoria As ComboBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents cboedocivil As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents cbosexo As ComboBox
    Friend WithEvents txtmaterno As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtpaterno As TextBox
    Friend WithEvents txtnombre As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents dtpCaptura As DateTimePicker
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtcodigo As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents cbopertenece As ComboBox
    Friend WithEvents cbobanco2 As ComboBox
    Friend WithEvents txtclabe2 As TextBox
    Friend WithEvents txtcuenta2 As TextBox
    Friend WithEvents Label47 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents cmdincidencias As Button
    Friend WithEvents cmdprestamo As Button
    Friend WithEvents Label52 As Label
    Friend WithEvents txtExtra As TextBox
    Friend WithEvents cmdJuridico As System.Windows.Forms.Button
    Friend WithEvents chkInfonavit As System.Windows.Forms.CheckBox

    Friend WithEvents cmdPension As System.Windows.Forms.Button

    Friend WithEvents cmdIncapacidad As System.Windows.Forms.Button
    Friend WithEvents dtFecPlanta As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtInicio As System.Windows.Forms.TextBox
    Friend WithEvents txtFin As System.Windows.Forms.TextBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents cmdFamiliar As System.Windows.Forms.Button
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents txtTelefono As System.Windows.Forms.TextBox
    Friend WithEvents cmdDocumentos As System.Windows.Forms.Button
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents dtpFinContrato As System.Windows.Forms.DateTimePicker
    Friend WithEvents cmdimss As System.Windows.Forms.Button
    Friend WithEvents cmdInfonavit As System.Windows.Forms.Button
    Friend WithEvents cmdPrestam As System.Windows.Forms.Button
    Friend WithEvents cmdFonacot As System.Windows.Forms.Button

End Class
